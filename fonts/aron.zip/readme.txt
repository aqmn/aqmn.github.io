我们将对这款字体开放授权，用户可以自由地将其应用于各种设计场景中，希望你能喜欢
Available for free in both personal & commercial projects.

Typeface Design: 电气香蕉FizzBanana
Graphic Design: ACAN Design Studio

https://www.behance.net/2577985956a5d0
https://www.behance.net/AcanDesign

