It's a variable display/body font, I made as a university project. ->
-> Made at the Media Design Institute, EKCE, Eger, Hungary.

FREE for PERSONAL and COMMERCIAL USE.

(I'm a broke student please support if you can)

https://vertebruh.gumroad.com/l/neuekainevf

https://www.behance.net/oszkrsztany


